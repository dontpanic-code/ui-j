import { ChatParticipantStatus } from './chat-participant-status.enum';
import { Localization } from './localization';
export declare function chatParticipantStatusDescriptor(status: ChatParticipantStatus, localization: Localization): string;
