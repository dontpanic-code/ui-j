export declare enum ScrollDirection {
    Top = 0,
    Bottom = 1
}
