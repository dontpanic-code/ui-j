export declare enum Theme {
    Custom = "custom-theme",
    Light = "light-theme",
    Dark = "dark-theme"
}
