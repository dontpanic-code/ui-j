export declare class ParticipantMetadata {
    totalUnreadMessages: number;
}
