export declare enum ChatParticipantType {
    User = 0,
    Group = 1
}
