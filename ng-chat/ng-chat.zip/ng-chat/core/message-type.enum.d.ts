export declare enum MessageType {
    Text = 1,
    File = 2,
    Image = 3
}
