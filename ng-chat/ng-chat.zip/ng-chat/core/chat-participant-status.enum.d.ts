export declare enum ChatParticipantStatus {
    Online = 0,
    Busy = 1,
    Away = 2,
    Offline = 3
}
