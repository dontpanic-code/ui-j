export declare class Guid {
    static newGuid(): string;
}
