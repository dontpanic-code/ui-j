export var Theme;
(function (Theme) {
    Theme["Custom"] = "custom-theme";
    Theme["Light"] = "light-theme";
    Theme["Dark"] = "dark-theme";
})(Theme || (Theme = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGhlbWUuZW51bS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL25nLWNoYXQvY29yZS90aGVtZS5lbnVtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBTixJQUFZLEtBS1g7QUFMRCxXQUFZLEtBQUs7SUFFYixnQ0FBdUIsQ0FBQTtJQUN2Qiw4QkFBcUIsQ0FBQTtJQUNyQiw0QkFBbUIsQ0FBQTtBQUN2QixDQUFDLEVBTFcsS0FBSyxLQUFMLEtBQUssUUFLaEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBUaGVtZVxyXG57XHJcbiAgICBDdXN0b20gPSAnY3VzdG9tLXRoZW1lJyxcclxuICAgIExpZ2h0ID0gJ2xpZ2h0LXRoZW1lJyxcclxuICAgIERhcmsgPSAnZGFyay10aGVtZSdcclxufVxyXG4iXX0=