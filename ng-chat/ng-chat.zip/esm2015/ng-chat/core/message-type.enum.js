export var MessageType;
(function (MessageType) {
    MessageType[MessageType["Text"] = 1] = "Text";
    MessageType[MessageType["File"] = 2] = "File";
    MessageType[MessageType["Image"] = 3] = "Image";
})(MessageType || (MessageType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS10eXBlLmVudW0uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9uZy1jaGF0L2NvcmUvbWVzc2FnZS10eXBlLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxDQUFOLElBQVksV0FLWDtBQUxELFdBQVksV0FBVztJQUVuQiw2Q0FBUSxDQUFBO0lBQ1IsNkNBQVEsQ0FBQTtJQUNSLCtDQUFTLENBQUE7QUFDYixDQUFDLEVBTFcsV0FBVyxLQUFYLFdBQVcsUUFLdEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBNZXNzYWdlVHlwZVxyXG57XHJcbiAgICBUZXh0ID0gMSxcclxuICAgIEZpbGUgPSAyLFxyXG4gICAgSW1hZ2UgPSAzXHJcbn1cclxuIl19