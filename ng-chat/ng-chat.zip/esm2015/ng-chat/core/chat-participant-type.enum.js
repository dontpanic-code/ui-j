export var ChatParticipantType;
(function (ChatParticipantType) {
    ChatParticipantType[ChatParticipantType["User"] = 0] = "User";
    ChatParticipantType[ChatParticipantType["Group"] = 1] = "Group";
})(ChatParticipantType || (ChatParticipantType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1wYXJ0aWNpcGFudC10eXBlLmVudW0uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9uZy1jaGF0L2NvcmUvY2hhdC1wYXJ0aWNpcGFudC10eXBlLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxDQUFOLElBQVksbUJBSVg7QUFKRCxXQUFZLG1CQUFtQjtJQUUzQiw2REFBSSxDQUFBO0lBQ0osK0RBQUssQ0FBQTtBQUNULENBQUMsRUFKVyxtQkFBbUIsS0FBbkIsbUJBQW1CLFFBSTlCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gQ2hhdFBhcnRpY2lwYW50VHlwZVxyXG57XHJcbiAgICBVc2VyLFxyXG4gICAgR3JvdXBcclxufVxyXG4iXX0=